# Landing Page assignment 007 — Cocoa Corner

Demo landing page with 2 product SKUs and a sample order form. Product image files go in `assets/products/`.


## Google Sheet columns (create sheet named `Orders`)
`Timestamp | Customer | Phone | Address | Note | Items | Total`

## Google Apps Script starter
Create/open the Google Sheet → Extensions → Apps Script, paste:

```javascript
function doPost(e) {
  const sheet = SpreadsheetApp.getActiveSpreadsheet().getSheetByName('Orders');
  const data = JSON.parse(e.postData.contents);
  sheet.appendRow([
    new Date(), data.customer, data.phone, data.address, data.note || '',
    JSON.stringify(data.items), data.total
  ]);
  return ContentService.createTextOutput(JSON.stringify({ok:true}))
    .setMimeType(ContentService.MimeType.JSON);
}
```
Deploy → New deployment → Web app → Execute as Me → Who has access: Anyone (if appropriate for class demo) → Deploy. Copy the Web App URL and paste it into `sheetEndpoint` in `index.html`.


## Publish with GitHub Pages
1. Create a GitHub repository and upload `index.html`, `README.md`, and the `assets/products/` folder (include images and/or a placeholder README so the folder exists).
2. Repository Settings → Pages → Build and deployment → Deploy from branch → choose `main` and `/ (root)` → Save.
3. Open the generated Pages URL to test. For a custom domain, configure it in the Pages settings and update DNS records with your domain provider.
