Place product photos here, for example cc-01.jpg and cc-02.jpg, matching the image paths in index.html.
